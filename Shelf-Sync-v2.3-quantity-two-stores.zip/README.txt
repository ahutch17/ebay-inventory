SHELF SYNC v2.3 — QUANTITY + TWO EBAY STORES

Upload these four files to the existing Shelf Sync GitHub repository and replace the old copies:
1. app.js
2. index.html
3. firebase.js
4. service-worker.js

Do not replace manifest.json or the app icons for this upgrade.

WHAT CHANGED
- Shows Available quantity on every listing row.
- Shows Out of stock when Available quantity is 0.
- Shows and allows editing quantity in the listing detail card.
- Adds e-dh19 and e-dh20 store labels.
- Adds an All stores filter.
- Requires choosing e-dh19 or e-dh20 before selecting a CSV.
- Keeps sold-listing cleanup limited to the selected store.
- Includes store and quantity in the copied SEO prompt.
- Updates Firebase storage so the store label syncs across devices.
- Bumps the offline cache to shelf-sync-v5.

FIRST IMPORT AFTER THE UPGRADE
1. Open Import CSV.
2. Choose e-dh19 and select the separate e-dh19 Active listings CSV.
3. Then repeat for e-dh20 with the separate e-dh20 CSV.
4. Existing listings will receive their store label when they match the imported CSV.
5. Listings not imported yet temporarily show “store not set.”

IMPORTANT
Always choose the correct store before selecting its CSV. The app only checks that selected store for missing/sold listings, so one store’s import cannot remove the other store’s listings.

If the phone still shows the old version after GitHub publishes the files, fully close Shelf Sync and reopen it. The new service worker uses cache version shelf-sync-v5.
